
public class Test {

 public static void main(String[] args) {
	 String k="big ";
	 k=k.concat("crowded ");
	 k+="city";
	 System.out.println(k);
}
}
