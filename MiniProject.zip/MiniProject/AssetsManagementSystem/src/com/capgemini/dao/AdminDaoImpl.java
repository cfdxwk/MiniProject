package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.connection.ConnectionFactory;
import com.capgemini.exception.AssetException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;

public class AdminDaoImpl implements AdminDao {

	ConnectionFactory conFactory = ConnectionFactory.getInstance();
	final Logger AdminDaoLogger;
	
	public AdminDaoImpl() {
		AdminDaoLogger = Logger.getLogger(AdminDaoImpl.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
	}

	@Override
	public int insertNewAsset(Asset asset) {
		
		
		AdminDaoLogger.info("In insertNewAsset method");
		String query = "Insert into Asset values(?,?,?,?)";  // query for inserting values into asset table
		String querySequence = "SELECT asset_id_seq.NEXTVAL FROM DUAL";
		int assetId = 0, resultset = 0;
		try (Connection conn = conFactory.getConnection();
				PreparedStatement ptmt1 = conn.prepareStatement(query);
				PreparedStatement ptmt2 = conn.prepareStatement(querySequence);) {

			ResultSet rs = ptmt2.executeQuery();
			while (rs.next()) {
				assetId = rs.getInt(1);
				break;
			}
			rs.close();
			ptmt1.setInt(1, assetId);
			ptmt1.setString(2, asset.getAssetName());
			ptmt1.setString(3, asset.getAssetDes());
			ptmt1.setInt(4, asset.getQuantity());

			resultset = ptmt1.executeUpdate();
			conn.commit();

		} catch (SQLException ex) {
			AdminDaoLogger.error("SQLException in insertNewAsset method");
			ex.printStackTrace();
		}
		return resultset;
	}

	@Override
	public int changeExistingAsset(Asset asset) {
		/*
		 * private String assetName; private String assetDes; private int quantity;
		 */
		
		AdminDaoLogger.info("In changeExistingAsset method.");
		// query for upadting the asset table
		String query = "update Asset set assetName=?, assetDes=?, quantity=? where assetId=? ";
		int rows = 0;
		try (Connection conn = conFactory.getConnection(); PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setString(1, asset.getAssetName());
			pstat.setString(2, asset.getAssetDes());
			pstat.setInt(3, asset.getQuantity());
			pstat.setInt(4, asset.getAssetId());

			rows = pstat.executeUpdate(); // how many rows affected

		} catch (SQLException e) {
			AdminDaoLogger.error("SQLException : " + e.getMessage());
			e.printStackTrace();
		}
		return rows;

	}

	@Override
	public List<AssetRequest> viewAllRequests() {
		
		AdminDaoLogger.info("In viewAllRequests method.");
		// query for retrieving all requests from asset request table
		String queryString = "SELECT * FROM AssetRequest";
		ArrayList<AssetRequest> listAssetRequest = new ArrayList<AssetRequest>();
		try (Connection conn = conFactory.getConnection(); Statement stat = conn.createStatement();) {
			ResultSet rs = stat.executeQuery(queryString);
			while (rs.next()) {
				AssetRequest assetRequest = new AssetRequest();
				
				int assetRequestId = rs.getInt("assetRequestId"); // we get the values from entity named assetRequestId
				int assetId = rs.getInt("assetId");
				int empNo = rs.getInt("empNo");
				int quantity = rs.getInt("quantity");
				String status = rs.getString("status");

				assetRequest.setAssetRequestId(assetRequestId);
				assetRequest.setAssetId(assetId);
				assetRequest.setEmpNo(empNo);
				assetRequest.setQuantity(quantity);
				assetRequest.setStatus(status);
				listAssetRequest.add(assetRequest);
			}
			rs.close();
		} catch (SQLException ex) {
			AdminDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return listAssetRequest;
	}

	@Override
	public int updateStatus(int assetRequestId, String status) throws AssetException {
		
		AdminDaoLogger.info("In updateStatus method.");
		// query for updating status in asset request table
		String query = "update AssetRequest set status=? where assetRequestId=?";
		
		AssetRequest request = selectRequestById(assetRequestId);
		int assetId = request.getAssetId(); // getting asset id
		int empNo = request.getEmpNo();
		int requestedQuantity = request.getQuantity();
		//System.out.println(request);
		
		int availableQuantity = selectAssetById(request.getAssetId()).getQuantity();
		
		if (status.equals("Allocated") && requestedQuantity > availableQuantity) {
			throw new AssetException("Not enough quantity");
		}
		
		String queryString = "update Asset set quantity=? where assetId=?";
		
		String queryAllocation = "insert into assetallocation values(?,?,?)";
		
		String querySequence = "SELECT asset_allocation_seq.NEXTVAL FROM DUAL";
		
		int rows = 0, assetRows = 0;
		try (Connection conn = conFactory.getConnection();
				PreparedStatement pstat = conn.prepareStatement(query);
				PreparedStatement pstat2 = conn.prepareStatement(queryString);
				PreparedStatement pstat3 = conn.prepareStatement(queryAllocation);
				PreparedStatement pstat4 = conn.prepareStatement(querySequence);) {
			pstat.setString(1, status);
			pstat.setInt(2, assetRequestId);
			rows = pstat.executeUpdate(); // how many rows affected
			
			if (status.equals("Allocated")) {
				pstat2.setInt(1, availableQuantity - request.getQuantity());
				pstat2.setInt(2, assetId);
				//System.out.println(assetId);
				assetRows = pstat2.executeUpdate();
				
				ResultSet rs = pstat4.executeQuery();  // for generating id
				int assetAllocationId=0;
				while (rs.next()) {
					assetAllocationId = rs.getInt(1);
					break;
				}
				
				pstat3.setInt(1, assetAllocationId);
				pstat3.setInt(2, assetId);
				pstat3.setInt(3, empNo);
				pstat3.executeUpdate();
			}
		} catch (SQLException e) {
			AdminDaoLogger.error("SQLException : " + e.getMessage());
			e.printStackTrace();
		}
		return rows;
	}

	public AssetRequest selectRequestById(int assetRequestId) {
		AdminDaoLogger.info("In updateStatus method.");
		// query for getting a particular asset request by asset request id
		String query = "Select * From AssetRequest where assetRequestId=?";
		AssetRequest request = null;
		try (Connection conn = conFactory.getConnection(); PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setInt(1, assetRequestId);
			ResultSet rs = pstat.executeQuery();
			while (rs.next()) {
				request = new AssetRequest();
				int assetId = rs.getInt("assetId");
				int empNo = rs.getInt("empNo");
				int quantity = rs.getInt("quantity");
				String status = rs.getString("status");
				request.setAssetRequestId(assetRequestId);
				request.setAssetId(assetId);
				request.setEmpNo(empNo);
				request.setQuantity(quantity);
				request.setStatus(status);
				break;
			}
			rs.close();
		
		} catch (SQLException ex) {
			AdminDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return request;
	}

	@Override
	public Asset selectAssetById(int assetId) throws AssetException{
		AdminDaoLogger.info("In selectAssetById method.");
		// query for getting a particular asset by asset id
		String query = "select * from asset where assetId=?";
		Asset asset = null;
		try (Connection conn = conFactory.getConnection(); PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setInt(1, assetId);
			ResultSet rs = pstat.executeQuery();
			if (rs.next()) {
				asset = new Asset();
				String assetName = rs.getString("assetName");
				String assetDes = rs.getString("assetDes");
				int quantity = rs.getInt("quantity");
				asset.setAssetId(assetId);
				asset.setAssetName(assetName);
				asset.setAssetDes(assetDes);
				asset.setQuantity(quantity);
			}
			else {
				throw new AssetException("Please Enter a valid asset Id");
			}
			rs.close();
		} catch (SQLException ex) {
			AdminDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return asset;
	}

	@Override
	public List<Asset> findAllocatedAsset() {
		AdminDaoLogger.info("In findAllocatedAsset method.");
		// query for getting a particular asset request by status
		String bringRequests = "select * from assetrequest where status=?";
		List<AssetRequest> allocatedAssetRequests = new ArrayList<AssetRequest>();
		try (Connection conn = conFactory.getConnection();
				PreparedStatement pstat = conn.prepareStatement(bringRequests);
				) {
			pstat.setString(1, "Allocated");
			ResultSet rs = pstat.executeQuery();
			while (rs.next()) {
				AssetRequest request = new AssetRequest();
				int assetRequestId = rs.getInt("assetRequestId");
				int assetId = rs.getInt("assetId");
				int empNo = rs.getInt("empNo");
				int quantity = rs.getInt("quantity");
				String status = rs.getString("status");
				request.setAssetRequestId(assetRequestId);
				request.setAssetId(assetId);
				request.setEmpNo(empNo);
				request.setQuantity(quantity);
				request.setStatus(status);
				allocatedAssetRequests.add(request);
			}
			rs.close();
		} catch (SQLException ex) {
			AdminDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		
		HashMap<Integer, Integer> map = new HashMap<>();
		for (AssetRequest request : allocatedAssetRequests) {
			int assetId = request.getAssetId();
			int quantity = request.getQuantity();
			if (map.containsKey(assetId)) {
				int have = map.get(assetId);
				map.put(assetId, have + quantity);
			} else {
				map.put(assetId, quantity);
			}
		}
		List<Asset> allAsset, allocatedAsset = new ArrayList<Asset>();
		allAsset = findAllAssets();
		Iterator mapIterator = map.entrySet().iterator();
		for (Asset asset : allAsset) {
			if (map.containsKey(asset.getAssetId())) {
				asset.setQuantity(map.get(asset.getAssetId()));
				allocatedAsset.add(asset);
			}
		}
		return allocatedAsset;
	}

	@Override
	public List<Asset> findUnallocatedAsset() {
		AdminDaoLogger.info("In findUnallocatedAsset method.");
		List<Asset> allAsset, unAllocatedAsset = new ArrayList<Asset>();
		allAsset = findAllAssets();
		for (Asset asset : allAsset) {
			if (asset.getQuantity() > 0) {
				unAllocatedAsset.add(asset);
			}
		}
		return unAllocatedAsset;
	}

	public List<Asset> findAllAssets() {
		AdminDaoLogger.info("In findAllAssets method.");
		String query = "select * from asset";
		List<Asset> allAsset = new ArrayList<Asset>();
		try (Connection conn = conFactory.getConnection();
				Statement stat = conn.createStatement();
				ResultSet rs = stat.executeQuery(query);) {
			while (rs.next()) {
				Asset asset = new Asset();
				int assetId = rs.getInt("assetId");
				String assetName = rs.getString("assetName");
				String assetDes = rs.getString("assetDes");
				int quantity = rs.getInt("quantity");
				asset.setAssetId(assetId);
				asset.setAssetName(assetName);
				asset.setAssetDes(assetDes);
				asset.setQuantity(quantity);
				allAsset.add(asset);
			}
		} catch (SQLException ex) {
			AdminDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return allAsset;
	}
}