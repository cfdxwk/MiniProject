package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.connection.ConnectionFactory;
import com.capgemini.exception.AssetException;
import com.capgemini.exception.EmployeeException;
import com.capgemini.model.AssetRequest;

public class ManagerDaoImpl implements ManagerDao{
	
	ConnectionFactory conFactory = ConnectionFactory.getInstance();
	final Logger ManagerDaoLogger;
	
	public ManagerDaoImpl() {
		ManagerDaoLogger = Logger.getLogger(ManagerDaoImpl.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
	}

	@Override
	public int insertRequest(AssetRequest request) {
		ManagerDaoLogger.info("In insertRequest method.");
		String query = "INSERT INTO AssetRequest(assetRequestId,assetId,empNo, managerId, quantity,status) VALUES(?,?,?,?,?,?)";
		String querySequence = "SELECT asset_request_seq.NEXTVAL FROM DUAL";
		int assetRequestId = 0, resultset=0;
		try (Connection conn = conFactory.getConnection();
				PreparedStatement ptmt1 = conn.prepareStatement(query);
				PreparedStatement ptmt2 = conn.prepareStatement(querySequence);) {

			ResultSet rs = ptmt2.executeQuery();
			while (rs.next()) {
				assetRequestId = rs.getInt(1);
				break;
			}
			rs.close();
			ptmt1.setInt(1, assetRequestId);
			ptmt1.setInt(2, request.getAssetId());
			ptmt1.setInt(3, request.getEmpNo());
			ptmt1.setString(4, request.getManagerId());
			ptmt1.setInt(5, request.getQuantity());
			ptmt1.setString(6, request.getStatus());
			resultset= ptmt1.executeUpdate();
			conn.commit();

		} catch (SQLException ex) {
			ManagerDaoLogger.error("SQLException : " + ex.getMessage());
			ex.printStackTrace();
		}
		return resultset;
	}
	
	@Override
	public AssetRequest selectRequestById(int assetRequestId) throws AssetException{
		ManagerDaoLogger.info("In selectRequestById method.");
		String query= "Select * From AssetRequest where assetRequestId=?";
		AssetRequest request=null;
		try (Connection conn = conFactory.getConnection(); 
				PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setInt(1, assetRequestId);
			ResultSet rs = pstat.executeQuery();
			if (rs.next()) {
				request= new AssetRequest();
				int assetId = rs.getInt("assetId");
				int empNo = rs.getInt("empNo");
				int quantity = rs.getInt("quantity");
				String managerId = rs.getString("manageId");
				String status = rs.getString("status");
				request.setAssetRequestId(assetRequestId);
				request.setAssetId(assetId);
				request.setEmpNo(empNo);
				request.setManagerId(managerId);
				request.setQuantity(quantity);
				request.setStatus(status);
			}
			else {
				throw new AssetException("Please enter a valid Asset Request Id");
			}
			rs.close();
		} catch (SQLException ex) {
			ManagerDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return request;
	}
	
	@Override
	public boolean selectAssetById(int assetId) throws AssetException {
		ManagerDaoLogger.info("In selectAssetById method.");
		String query = "select * from asset where assetId=?";
		try (Connection conn = conFactory.getConnection(); PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setInt(1, assetId);
			ResultSet rs = pstat.executeQuery();
			if(rs.next()) {
				return true;
			}
			else {
				throw new AssetException("Please enter a valid Asset Id");
			}
		} catch (SQLException ex) {
			ManagerDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return false;
	}

	@Override
	public boolean selectEmployeeByNo(int empNo, String managerId) throws EmployeeException {
		ManagerDaoLogger.info("In selectEmployeeByNo method.");
		String query = "select * from Employee where empNo=? and managerId=?";
		try (Connection conn = conFactory.getConnection(); PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setInt(1, empNo);
			pstat.setString(2, managerId);
			ResultSet rs = pstat.executeQuery();
			if(rs.next()) {
				return true;
			}
			else {
				throw new EmployeeException("Please enter a valid Employee No");
			}
		} catch (SQLException ex) {
			ManagerDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return false;
	}
	
	@Override
	public List<AssetRequest>selectRequestsByManagerId(String managerId){
		ManagerDaoLogger.info("In selectRequestsByManagerId method.");
		String query = "select * from assetRequest where managerId=?";
		ArrayList<AssetRequest>requests = new ArrayList<AssetRequest>();
		try (Connection conn = conFactory.getConnection(); 
				PreparedStatement pstat = conn.prepareStatement(query);) {
			pstat.setString(1, managerId);
			
			ResultSet rs = pstat.executeQuery();
			while(rs.next()) {
				AssetRequest request = new AssetRequest();
				int assetRequestId = rs.getInt("assetRequestId");
				int assetId = rs.getInt("assetId");
				int empNo = rs.getInt("empNo");
				int quantity = rs.getInt("quantity");
				String status = rs.getString("status");

				request.setAssetRequestId(assetRequestId);
				request.setAssetId(assetId);
				request.setEmpNo(empNo);
				request.setManagerId(managerId);
				request.setQuantity(quantity);
				request.setStatus(status);
				
				requests.add(request);
			}
			rs.close();
		} catch (SQLException ex) {
			ManagerDaoLogger.error("SQLException : " + ex.getMessage());
			System.err.format("SQL State: %s\n%s", ex.getSQLState(), ex.getMessage());
		}
		return requests;
	}
}