package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.connection.ConnectionFactory;
import com.capgemini.exception.AssetException;

public class AuthenticationDaoImpl implements AuthenticationDao{
	
	ConnectionFactory conFactory = ConnectionFactory.getInstance();
	final Logger AuthenticationDaoLogger;
	
	public AuthenticationDaoImpl() {
		AuthenticationDaoLogger = Logger.getLogger(AuthenticationDaoImpl.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
	}

	@Override
	public boolean checkUser(String userId, String password) throws AssetException{
		AuthenticationDaoLogger.info("In checkUser method");
		String query = "select * from user_master where userid=? and userpassword=?";
		try(Connection conn = conFactory.getConnection();
				PreparedStatement pstat = conn.prepareStatement(query);
				){
			pstat.setString(1, userId);
			pstat.setString(2, password);
			ResultSet rs = pstat.executeQuery();
			if(rs.next()) {
				return true;
			}
			else {
				throw new AssetException("Invalid Username or Password");
			}
		}catch(SQLException e) {
			AuthenticationDaoLogger.error("SQLException : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String userType(String userId) {
		AuthenticationDaoLogger.info("In userType method");
		String query = "select * from user_master where userid=?";
		String userType=null;
		try(Connection conn = conFactory.getConnection();
				PreparedStatement pstat = conn.prepareStatement(query);
				){
			pstat.setString(1, userId);
			ResultSet rs = pstat.executeQuery();
			if(rs.next()) {
				userType=rs.getString("userType");
			}
		}catch(SQLException e) {
			AuthenticationDaoLogger.error("SQLException : " + e.getMessage());
			e.printStackTrace();
		}
		return userType;
	}
}