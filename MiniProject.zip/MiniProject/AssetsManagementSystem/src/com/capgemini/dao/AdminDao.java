package com.capgemini.dao;

import java.util.List;

import com.capgemini.exception.AssetException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;

public interface AdminDao {
	public int insertNewAsset(Asset asset);
	public int changeExistingAsset(Asset asset);
	public List<AssetRequest> viewAllRequests();
	public int updateStatus(int assetRequestId, String status) throws AssetException;
	public List<Asset> findAllocatedAsset();
	public List<Asset> findUnallocatedAsset();
	public Asset selectAssetById(int assetId) throws AssetException;
}
