package com.capgemini.dao;

import java.util.List;

import com.capgemini.exception.AssetException;
import com.capgemini.exception.EmployeeException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;

public interface ManagerDao {
	public int insertRequest(AssetRequest request);
	public AssetRequest selectRequestById(int assetRequestId) throws AssetException;
	boolean selectAssetById(int assetId) throws AssetException;
	boolean selectEmployeeByNo(int empNo, String managerId) throws EmployeeException;
	List<AssetRequest>selectRequestsByManagerId(String managerId);

}
