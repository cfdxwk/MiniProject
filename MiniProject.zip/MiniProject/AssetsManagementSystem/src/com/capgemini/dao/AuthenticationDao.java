package com.capgemini.dao;

import com.capgemini.exception.AssetException;

public interface AuthenticationDao {
	
	public boolean checkUser(String userId, String password) throws AssetException;
	public String userType(String userId);

}
