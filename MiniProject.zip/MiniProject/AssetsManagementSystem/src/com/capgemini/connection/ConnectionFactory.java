package com.capgemini.connection;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

//created a conncetionFactory for establishing connection in main method with database
public class ConnectionFactory {

	private static ConnectionFactory connectionFactory = null;

	private static Properties properties = new Properties();

	private ConnectionFactory() {
		try {
			try (InputStream inputStream = new FileInputStream(".//resources/jdbc.properties")) {
				properties.load(inputStream);
				// properties.list(System.out);
				String dbDriver = properties.getProperty("db.driver");
				Class.forName(dbDriver);

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
	}

	public static ConnectionFactory getInstance() {
		if (connectionFactory == null) {
			connectionFactory = new ConnectionFactory();
		}
		return connectionFactory;
	}

	public Connection getConnection() throws SQLException {
		Connection conn = null;
		String dbUrl = properties.getProperty("db.url");
		String dbUserName = properties.getProperty("db.user");
		String dbPassword = properties.getProperty("db.password");
		conn = DriverManager.getConnection(dbUrl, dbUserName, dbPassword);
		return conn;
	}

}
