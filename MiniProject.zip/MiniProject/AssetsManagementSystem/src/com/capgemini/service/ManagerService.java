package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.AssetException;
import com.capgemini.exception.EmployeeException;
import com.capgemini.exception.QuantityException;
import com.capgemini.model.AssetRequest;

public interface ManagerService {
	
	public int addRequest(AssetRequest request);
	public AssetRequest viewRequest(int assetRequestId) throws AssetException;
	public boolean validateAssetId(int id) throws AssetException;
	public boolean validateEmpNo(int empNo, String managerId) throws EmployeeException;
	public boolean validateQuantity(int quantity) throws QuantityException;
	List<AssetRequest>selectRequestsByManagerId(String managerId);
	public AssetRequest viewRequestByYou(int assetRequestId, List<AssetRequest> requests) throws AssetException;

}
