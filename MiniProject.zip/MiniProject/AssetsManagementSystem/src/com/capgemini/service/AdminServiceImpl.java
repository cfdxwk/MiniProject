package com.capgemini.service;

import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.dao.AdminDao;
import com.capgemini.dao.AdminDaoImpl;
import com.capgemini.exception.AssetException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;

public class AdminServiceImpl implements AdminService{
	
	AdminDao dao = new AdminDaoImpl();
	final Logger AdminServiceLogger;

	public AdminServiceImpl() {
		AdminServiceLogger = Logger.getLogger(AdminServiceImpl.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
	}
	
	// inserts assets into Asset table and returns status
	@Override
	public int addNewAsset(Asset asset) {
		AdminServiceLogger.info("In addNewAsset method.");
		int status = dao.insertNewAsset(asset);
		return status;
	}
	
	// updates the Asset table and returns status
	@Override
	public int modifyExistingAsset(Asset asset) {
		AdminServiceLogger.info("In modifyExistingAsset method.");
		int status = dao.changeExistingAsset(asset);
		return status;
	}
	
	// used to view all the requests
	@Override
	public List<AssetRequest> showAllRequests() {
		AdminServiceLogger.info("In showAllRequests method.");
		List<AssetRequest>list = dao.viewAllRequests();
		return list;
	}

	// updates the status whether it is allocated or not
	@Override
	public int changeStatus(int assetRequestId, String status) throws AssetException {
		AdminServiceLogger.info("In changeStatus method.");
		int isChanged = dao.updateStatus(assetRequestId, status);
		return isChanged;
	}
	
	// gives the list of allocated assets
	@Override
	public List<Asset> showAllocatedAssets() {
		AdminServiceLogger.info("In showAllocatedAssets method.");
		return dao.findAllocatedAsset();
	}

	// gives the list of unallocated assets
	@Override
	public List<Asset> showUnallocatedAssets() {
		AdminServiceLogger.info("In showUnallocatedAssets method.");
		return dao.findUnallocatedAsset();
	}

	// used to view a particular asset by it's id
	@Override
	public Asset selectAssetById(int assetId) throws AssetException{
		AdminServiceLogger.info("In selectAssetById method.");
		return dao.selectAssetById(assetId);
	}

	// validates the asset name and returns false if the length<=25
	@Override
	public boolean validateAssetName(String assetName) {
		AdminServiceLogger.info("In validateAssetName method.");
		if(assetName.length()<=25)
			return true;
		return false;
	}

	// validates the asset description and returns false if the length<=25
	@Override
	public boolean validateAssetDesc(String assetDesc) {
		AdminServiceLogger.info("In validateAssetDesc method.");
		if(assetDesc.length()<=25)
			return true;
		return false;
	}

	// validates the asset quantity and returns false if quantity<0
	@Override
	public boolean validateAssetQuantity(int quantity) {
		AdminServiceLogger.info("In validateAssetQuantity method.");
		if(quantity>0)
			return true;
		else
			return false;
	}

	@Override
	public boolean idIsPresent(int id, List<AssetRequest> requests) {
		AdminServiceLogger.info("In idIsPresent method.");
		for(AssetRequest request:requests) {
			if(request.getAssetRequestId()==id)
				return true;
		}
		return false;
	}
}