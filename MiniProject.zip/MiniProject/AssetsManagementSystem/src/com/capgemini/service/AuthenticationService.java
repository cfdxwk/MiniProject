package com.capgemini.service;

import com.capgemini.exception.AssetException;

public interface AuthenticationService {
	
	public boolean verifyUser(String userId, String password) throws AssetException;
	public String userType(String userId);
	public boolean validateUserId(String userId);
	public boolean validatePassword(String password);

}
