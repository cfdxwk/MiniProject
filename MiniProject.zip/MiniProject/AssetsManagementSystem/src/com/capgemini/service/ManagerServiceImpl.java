package com.capgemini.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.dao.ManagerDao;
import com.capgemini.dao.ManagerDaoImpl;
import com.capgemini.exception.AssetException;
import com.capgemini.exception.EmployeeException;
import com.capgemini.exception.QuantityException;
import com.capgemini.model.AssetRequest;

public class ManagerServiceImpl implements ManagerService {

	ManagerDao dao = new ManagerDaoImpl();
	final Logger ManagerServiceLogger;

	public ManagerServiceImpl() {
		ManagerServiceLogger = Logger.getLogger(ManagerServiceImpl.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
	}
	@Override
	public int addRequest(AssetRequest request) {
		ManagerServiceLogger.info("In addRequest method.");
		int status = dao.insertRequest(request);
		return status;
	}

	@Override
	public AssetRequest viewRequest(int assetRequestId) throws AssetException{
		ManagerServiceLogger.info("In viewRequest method.");
		AssetRequest request = dao.selectRequestById(assetRequestId);
		return request;
	}

	@Override
	public boolean validateAssetId(int id) throws AssetException{
		ManagerServiceLogger.info("In validateAssetId method.");
		boolean isPresent = dao.selectAssetById(id);
		return isPresent;
	}

	@Override
	public boolean validateEmpNo(int empNo, String managerId) throws EmployeeException{
		ManagerServiceLogger.info("In validateEmpNo method.");
		boolean isPresent = dao.selectEmployeeByNo(empNo, managerId);
		
		return isPresent;
	}

	@Override
	public boolean validateQuantity(int quantity) throws QuantityException{
		ManagerServiceLogger.info("In validateQuantity method.");
		if(quantity<=0) {
			throw new QuantityException("Please Enter a valid quantity");
		}
		return false;
	}
	@Override
	public List<AssetRequest> selectRequestsByManagerId(String managerId) {
		return dao.selectRequestsByManagerId(managerId);
	}
	@Override
	public AssetRequest viewRequestByYou(int assetRequestId, List<AssetRequest> requests) throws AssetException {
		for(AssetRequest request:requests) {
			if(request.getAssetRequestId()==assetRequestId) {
				return request;
			}
		}
		throw new AssetException("Please enter a Id that belongs to you");
	}
}