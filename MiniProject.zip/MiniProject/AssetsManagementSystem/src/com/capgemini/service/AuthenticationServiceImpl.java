package com.capgemini.service;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.dao.AuthenticationDao;
import com.capgemini.dao.AuthenticationDaoImpl;
import com.capgemini.exception.AssetException;

public class AuthenticationServiceImpl implements AuthenticationService{
	
	AuthenticationDao dao = new AuthenticationDaoImpl();
	final Logger AuthenticationServiceLogger;

	public AuthenticationServiceImpl() {
		AuthenticationServiceLogger = Logger.getLogger(AuthenticationServiceImpl.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
	}

	@Override
	public boolean verifyUser(String userId, String password) throws AssetException {
		AuthenticationServiceLogger.info("In verifyUser method");
		boolean status = dao.checkUser(userId, password);
		return status;
	}

	@Override
	public String userType(String userId) {
		AuthenticationServiceLogger.info("In userType method");
		String type = dao.userType(userId);
		return type;
	}

	@Override
	public boolean validateUserId(String userId) {
		AuthenticationServiceLogger.info("In validateUserId method");
		if(userId.length()<=6)
			return true;
		return false;
	}

	@Override
	public boolean validatePassword(String password) {
		AuthenticationServiceLogger.info("In validatePassword method");
		if(password.length()<=50)
			return true;
		return false;
	}
}