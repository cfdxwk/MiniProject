package com.capgemini.service;

import java.util.List;

import com.capgemini.exception.AssetException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;

public interface AdminService {
	public int addNewAsset(Asset asset);
	public int modifyExistingAsset(Asset asset);
	public List<AssetRequest> showAllRequests();
	public int changeStatus(int assetRequestId,String status) throws AssetException;
	public Asset selectAssetById(int assetId) throws AssetException;
	public List<Asset> showAllocatedAssets();
	public List<Asset> showUnallocatedAssets();
	public boolean validateAssetName(String assetName);
	public boolean validateAssetDesc(String assetDesc);
	public boolean validateAssetQuantity(int quantity);
	public boolean idIsPresent(int id, List<AssetRequest> requests);
}