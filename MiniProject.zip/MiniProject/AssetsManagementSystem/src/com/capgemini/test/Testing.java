package com.capgemini.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dao.AdminDaoImpl;
import com.capgemini.dao.ManagerDaoImpl;
import com.capgemini.exception.AssetException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;

public class Testing {
	
	
	static AdminDaoImpl AdminTest;
	static ManagerDaoImpl ManagerTest;
	Asset asset;
	AssetRequest assetRequest;
	
	@BeforeClass
	public static void setup() {
		AdminTest= new AdminDaoImpl();
		ManagerTest= new ManagerDaoImpl();
		
	}
	
	// Positive test case for inserting new asset
	@Test
	public void insertNewAssetTest() {
		asset = new Asset("Laptops", "Acer", 10 );
		int actual= AdminTest.insertNewAsset(asset);
		int expected=1;
		assertEquals(expected, actual);
	}
	
	// Negative test case for inserting new asset
	@Test
	public void insertNewAssetTest1() {
		asset = new Asset("Laptops", "Acer", 10 );
		int actual= AdminTest.insertNewAsset(asset);
		int expected=0;
		assertEquals(expected, actual);
	}
	
	// Positive test case for updating an asset
	@Test
	public void changeExistingAssetTest() {
		asset = new Asset(100,"Laptops", "Asus", 10 );
		int actual= AdminTest.changeExistingAsset(asset);
		int expected=1;
		assertEquals(expected, actual);
	}
	
	// Negative test case for updating an asset
	@Test
	public void changeExistingAssetTest1() {
		asset = new Asset(100,"Laptops", "Asus", 10 );
		int actual= AdminTest.changeExistingAsset(asset);
		int expected=1;
		assertEquals(expected, actual);
	}
	
	// Positive Test case of viewAllRequest
	@Test
	public void viewAllRequestTest() {
		List<AssetRequest> requests = AdminTest.viewAllRequests();
		int actual = requests.size();
		int expected = 2;
		assertEquals(expected, actual);
	}
	
	// Negative Test case of viewAllRequest
	@Test
	public void viewAllRequestTest1() {
		List<AssetRequest> requests = AdminTest.viewAllRequests();
		int actual = requests.size();
		int expected = 0;
		assertEquals(expected, actual);
	}
	
	//Positive test case for finding allocated assets
	@Test
	public void findAllocatedAssetTest() {
		List<Asset> listTest= AdminTest.findAllocatedAsset();
		int actual= listTest.get(0).getQuantity();
		assertTrue(actual>0);
		
	}
	
	//Negative test case for finding allocated assets
	@Test
	public void findAllocatedAssetTest1() {
		List<Asset> listTest= AdminTest.findAllocatedAsset();
		int actual= listTest.get(0).getQuantity();
		assertTrue(actual<=0);
		
	}
	
	//Positive test case for finding Unallocated assets 
	@Test
	public void findUnallocatedAssetTest() {
		List<Asset> listTest= AdminTest.findUnallocatedAsset();
		int actual= listTest.get(0).getQuantity();
		assertTrue(actual>=0);
	}
	
	//Negative test case for finding Unallocated assets
	@Test
	public void findUnallocatedAssetTest1() {
		List<Asset> listTest= AdminTest.findUnallocatedAsset();
		int actual= listTest.get(0).getQuantity();
		assertTrue(actual<0);
	}
	
	// Positive test case for raising a request
	@Test
	public void insertRequestTest() {
		assetRequest= new AssetRequest(1,"manage", 1, 1, "unallocated");
		int actual= ManagerTest.insertRequest(assetRequest);
		int expected=1;
		assertEquals(expected, actual);
	}
	
	// Negative test case for raising a request
	@Test
	public void insertRequestTest1() {
		assetRequest= new AssetRequest(1,"manage", 1, 1, "unallocated");
		int actual= ManagerTest.insertRequest(assetRequest);
		int expected=0;
		assertEquals(expected, actual);
	}
	
	
}
