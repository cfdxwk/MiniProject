package com.capgemini.model;

public class AssetRequest {

	private int assetRequestId;
	private int assetId;
	private int empNo;
	private String managerId;
	private int quantity;
	private String status;
	
	public AssetRequest() {
		
	}
	

	public AssetRequest( int assetId, String managerId, int empNo, int quantity, String status) {
		super();
		
		this.assetId = assetId;
		this.empNo = empNo;
		this.quantity = quantity;
		this.status = status;
		this.managerId = managerId;
	}

	public int getAssetRequestId() {
		return assetRequestId;
	}

	public void setAssetRequestId(int assetRequestId) {
		this.assetRequestId = assetRequestId;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AssetRequest [assetRequestId=" + assetRequestId + ", assetId=" + assetId + ", empNo=" + empNo
				+ ", managerId=" + managerId + ", quantity=" + quantity + ", status=" + status + "]";
	}

	

}
