package com.capgemini.exception;

public class AssetException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public  AssetException(String msg) {
		super(msg);
	}
	
	
}
