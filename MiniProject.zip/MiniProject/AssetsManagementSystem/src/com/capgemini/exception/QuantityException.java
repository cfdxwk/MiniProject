package com.capgemini.exception;

public class QuantityException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public  QuantityException(String msg) {
		super(msg);
	}

}
