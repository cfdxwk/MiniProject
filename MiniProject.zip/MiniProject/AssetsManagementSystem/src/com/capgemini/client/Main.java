package com.capgemini.client;

import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.exception.AssetException;
import com.capgemini.exception.EmployeeException;
import com.capgemini.exception.QuantityException;
import com.capgemini.model.Asset;
import com.capgemini.model.AssetRequest;
import com.capgemini.service.AdminService;
import com.capgemini.service.AdminServiceImpl;
import com.capgemini.service.AuthenticationService;
import com.capgemini.service.AuthenticationServiceImpl;
import com.capgemini.service.ManagerService;
import com.capgemini.service.ManagerServiceImpl;

public class Main {
	public static void main(String[] args) {

		final Logger Mainlogger = Logger.getLogger(Main.class);
		PropertyConfigurator.configure(".\\resources\\log4j.properties");

		Scanner sc = new Scanner(System.in);
		String userId = null, password = null;
		boolean userVerified = false;
		AuthenticationService authtenticationService = new AuthenticationServiceImpl();
		boolean isValidId = false, isValidPassword = false;
		while (!userVerified) { // if userverified is true
			System.out.println("---------------------Welcome to Asset Management System--------------------------");
			do {
				System.out.println("Please enter your username");
				userId = sc.next();
				isValidId = authtenticationService.validateUserId(userId); // validating userId by validateUserId method
																			// in authentication service
				if (!isValidId) {
					Mainlogger.warn("Invalid UserName given");
					System.out.println("Please enter a valid username");
					continue;
				}
				System.out.println("Please enter your password");
				password = sc.next();
				isValidPassword = authtenticationService.validatePassword(password); // validating password by
																						// validatePassword method in
																						// authentication service
				if (!isValidPassword) {
					Mainlogger.warn("Invalid Password given");
					System.out.println("Please enter a valid password");
					continue;
				}
			} while (!isValidId || !isValidPassword);

			try {
				authtenticationService.verifyUser(userId, password); // verfiying login credentials
				userVerified = true;
			} catch (AssetException e) {
				Mainlogger.error("Exception thrown: " + e.getMessage());
				System.out.println(e.getMessage());
			}

			if (userVerified) {
				Mainlogger.info("User Verified");
				String userType = authtenticationService.userType(userId); // getting user type by user id
				if (userType.equals("manager")) {
					Mainlogger.info("Login as Manager");
					ManagerService service = new ManagerServiceImpl();
					int choice = 0;
					String managerId = userId;
					while (userVerified) {
						System.out.println(
								"---------------------------------Enter your choice----------------------------------");
						System.out.println("1. Add New Request");
						System.out.println("2. View Status ");
						System.out.println("3. Logout");
						choice = sc.nextInt();
						switch (choice) {
						case 1:
							Mainlogger.info("Adding new request");
							AssetRequest request = new AssetRequest();
							int id, empNo, quantity;

							System.out.println("Enter Asset Id");
							while (true) {
								id = sc.nextInt(); // we provide asset id for new request
								try {
									service.validateAssetId(id); // provided asset id is validated here
									
									Mainlogger.info("Correct Asset Id");
									break;
								} catch (AssetException e) {
									Mainlogger.error("Exception thrown: " + e.getMessage());
									System.out.println(e.getMessage());
								}
							}

							System.out.println("Enter Employee Number");
							while (true) {
								empNo = sc.nextInt(); // we provide emp no for new request
								try {
									service.validateEmpNo(empNo, managerId); // provided emp no is validated here
									Mainlogger.info("Correct Employee No");
									break;

								} catch (EmployeeException e) {
									Mainlogger.error("Exception thrown: " + e.getMessage());
									System.out.println(e.getMessage());
								}
							}

							System.out.println("Enter Quantity of Asset");
							while (true) {
								quantity = sc.nextInt(); // we provide quantity for new request
								try {
									service.validateQuantity(quantity); // provided quantity is validated here
									Mainlogger.info("Correct Quantity");
									break;

								} catch (QuantityException e) {
									Mainlogger.error("Exception thrown: " + e.getMessage());
									System.out.println(e.getMessage());
								}
							}

							String status = "Unallocated"; // for this request we initially assign status = Unallocated
							request.setAssetId(id);
							request.setEmpNo(empNo);
							request.setQuantity(quantity);
							request.setStatus(status);
							request.setManagerId(managerId);
							service.addRequest(request); // by addRequest method we add request

							break;
						case 2:
							// find out asset request ids belongs to current manager;
							List<AssetRequest> requests = service.selectRequestsByManagerId(managerId);
							System.out.println("Id of requests raised by you: " + managerId);
							for (AssetRequest request2 : requests) {
								System.out.println(request2.getAssetRequestId());
							}
							int assetRequestId;
							AssetRequest assetRequest;
							while (true) {
								System.out.println("Enter Asset Request Id");
								assetRequestId = sc.nextInt(); // we enter asset req id for viewing request
								try {
									assetRequest = service.viewRequestByYou(assetRequestId, requests); // by viewRequest
																										// method in
																										// service we
																										// view our
																										// request
									Mainlogger.info("Valid Asset Request Id");
									System.out.println(assetRequest);
									break;
								} catch (AssetException e) {
									Mainlogger.error("Exception thrown: " + e.getMessage());
									System.out.println(e.getMessage());
								}
							}

							break;
						case 3:
							Mainlogger.info("Logout");
							userVerified = false; // for logging out we use break and make userVerified as false
							break;

						default:
							System.out.println("Invalid Choice");
							Mainlogger.warn("Wrong option selected");

						}

					}

				}

				else {
					Mainlogger.info("Login as Admin");
					AdminService service = new AdminServiceImpl();
					int choice = 0;
					while (userVerified) {
						System.out.println(
								"---------------------------------Enter your choice----------------------------------");
						System.out.println("1. Add New Asset");
						System.out.println("2. Modify Existing Asset");
						System.out.println("3. Approve or Reject a Request");
						System.out.println("4. Show Unallocated Instances of Assets");
						System.out.println("5. Show Allocated Instances of Assets");
						System.out.println("6. Logout");
						choice = sc.nextInt();
						switch (choice) {
						case 1:
							Mainlogger.info("Adding Asset");
							Asset asset = new Asset();
							System.out.println("Enter Asset Name");
							String assetName = null;
							while (true) {
								assetName = sc.next(); // we enter asset name for add new asset request
								if (!service.validateAssetName(assetName)) { // asset name is being validated
									System.out.println("Please enter a valid asset name");
									Mainlogger.warn("Invalid Asset Name");
								} else {
									Mainlogger.info("Correct Asset Name");
									break;
								}
							}

							System.out.println("Please Enter Asset Description");
							String assetDesc = null;
							while (true) {
								assetDesc = sc.next(); // we enter asset description for request
								if (!service.validateAssetDesc(assetDesc)) { // asset description is being validated
									System.out.println("Please enter valid asset desc");
									Mainlogger.warn("Invalid Asset Desc");
								} else {
									Mainlogger.info("Correct Asset Desc");
									break;
								}
							}

							System.out.println("Enter Quantity of Asset");

							int quantity = 0;
							while (true) {
								quantity = sc.nextInt(); // we enter quantity for request
								if (!service.validateAssetQuantity(quantity)) { // quantity is being validated
									System.out.println("Please enter valid asset quantity");
									Mainlogger.warn("Invalid Asset Quantity");
								} else {
									Mainlogger.info("Correct Quantity");
									break;
								}
							}
							asset.setAssetName(assetName);
							asset.setAssetDes(assetDesc);
							asset.setQuantity(quantity);
							service.addNewAsset(asset); // asset is added with the above provided details
							break;
						case 2:

							Asset tempAsset = new Asset();
							int assetId;

							while (true) {
								System.out.println("Enter Asset Id");
								assetId = sc.nextInt();
								try {
									tempAsset = service.selectAssetById(
											assetId); /*
														 * for updating first we get the asset to be updated by asset id
														 */
									Mainlogger.info("Correct Asset Id");
									break;

								} catch (AssetException e) {
									Mainlogger.error("Exception thrown: " + e.getMessage());
									System.out.println(e.getMessage());
								}
							}
							System.out.println(tempAsset); // asset to be updated is printed here
							int modifyChoice = 0;

							while (!(modifyChoice == 1 || modifyChoice == 2 || modifyChoice == 3)) {
								System.out.println(
										"1. Change Asset Name 2. Change Asset Description 3. Change Asset Quantity");
								modifyChoice = sc.nextInt();
								switch (modifyChoice) { // choice for area to be updated
								case 1:
									String newName;
									while (true) {
										System.out.println("Enter the new Name of Asset");
										newName = sc.next();
										if (!service.validateAssetName(newName)) {
											System.out.println("Invalid Asset Name");
											Mainlogger.warn("Invalid Asset Name");

										} else {
											Mainlogger.info("Valid Asset Name");
											break;
										}

									}
									tempAsset.setAssetName(newName); // setting new asset name
									System.out.println("Asset Name changed successfully");
									break;
								case 2:
									String newDes;
									while (true) {
										System.out.println("Enter the new Description of Asset");
										newDes = sc.next();
										if (!service.validateAssetDesc(newDes)) {
											System.out.println("Invalid Asset description");
											Mainlogger.warn("Invalid Asset Desc");
										} else {
											Mainlogger.info("Valid Asset Desc");
											break;
										}
									}
									tempAsset.setAssetName(newDes); // setting new asset description
									System.out.println("Asset Desc changed successfully");
									break;
								case 3:
									int newQuantity;
									while (true) {
										System.out.println("Enter the quantity");
										newQuantity = sc.nextInt();
										if (!service.validateAssetQuantity(newQuantity)) {
											System.out.println("Invalid Quantity");
											Mainlogger.warn("Invalid Quantity");
										} else {
											Mainlogger.info("Valid Quantity");
											break;
										}

									}
									tempAsset.setQuantity(newQuantity); // setting new asset quantity
									System.out.println("Asset quantity changed successfully");
									break;
								default:
									Mainlogger.info("Invalid choice");
									System.out.println("Invalid choice");
									break;
								}
							}

							service.modifyExistingAsset(tempAsset); // updating the selected asset with the above
																	// provided details
							break;
						case 3:
							Mainlogger.info("Accepting or Rejecting a request");
							List<AssetRequest> requests = service.showAllRequests(); // we get the list of all requests
							Mainlogger.info("Showing All requests");
							int count = 0;
							for (AssetRequest assetRequest : requests) {
								if (assetRequest.getStatus().equals("Unallocated")) {
									System.out.println(assetRequest);
									count++;
								}

							}

							int id;
							boolean getOut = false;

							if (count == 0) {
								System.out.println("No requests are there");
								break;
							}

							while (true) {
								System.out.println("Enter Request Id to Change Status");
								System.out.println("Enter -1 to exit");
								id = sc.nextInt(); // we enter id to change status
								if (id == -1) {
									getOut = true;
									break;
								}
								if (!service.idIsPresent(id, requests)) {
									System.out.println("Please Enter a valid Asset Request Id");
									Mainlogger.warn("Invalid Asset Request Id");
								} else {
									Mainlogger.warn("Valid Asset Request Id");
									break;
								}
							}
							if (getOut) {
								break;
							}
							int statusChoice = 0;

							while (!(statusChoice == 1 || statusChoice == 2)) {
								System.out.println("1. Accept the Request 2. Reject the Request");
								statusChoice = sc.nextInt();
								switch (statusChoice) {
								case 1:
									try {

										service.changeStatus(id,
												"Allocated"); /*
																 * changeStatus method is called in service layer where
																 * the status is changed
																 */
										Mainlogger.info("Allocation done successfully");
										System.out.println("Request accepted");

									} catch (AssetException e) {
										Mainlogger.error("Exception thrown: " + e.getMessage());
										System.out.println(e.getMessage());
									}

									break;

								case 2:
									try {

										service.changeStatus(id, "Rejected");
										Mainlogger.info("Request rejected");
										System.out.println("Request rejected");

									} catch (AssetException e) {
										Mainlogger.error("Exception thrown: " + e.getMessage());
										System.out.println(e.getMessage());
									}
									break;

								default:
									Mainlogger.info("Invalid choice");
									System.out.println("Invalid choice");
									break;
								}
							}

							break;

						case 4:
							List<Asset> unallocatedAssets = service.showUnallocatedAssets();
							for (Asset unAllocatedAsset : unallocatedAssets) { // give the list of unallocated assets
								System.out.println(unAllocatedAsset);
							}
							break;

						case 5:
							List<Asset> allocatedAssets = service.showAllocatedAssets();
							for (Asset allocatedAsset : allocatedAssets) { // give the list of allocated assets
								System.out.println(allocatedAsset);
							}
							break;

						case 6:
							Mainlogger.info("Logout"); // for logging out
							userVerified = false;
							break;
						default:
							System.out.println("Invalid Choice");
							Mainlogger.warn("Invalid Choice");
						}
					}
				}
			}
		}
	}
}